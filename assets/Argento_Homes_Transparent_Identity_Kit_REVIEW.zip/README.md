# Argento Homes — Transparent Identity Extraction (Founder Review)

## Source and lineage
- Original source: `five28hertz-website/client/public/assets/Argento Homes Logo.png` (500 × 500, RGBA, dark square background embedded).
- Extracted on 2026-10-29 from its original pixels; no generated replacement leaf or substituted font.
- Working status: **EXTRACTED CANDIDATE / NOT CANONICAL MASTER** until founder approves fidelity.
- No change to Argento Homes mission, positioning, or logo identity is proposed.

## Files
- `Argento_Homes_Leaf_Transparent.png` — original multi-colored leaf, dark backing removed, transparent.
- `Argento_Homes_Gold_Wordmark_Transparent.png` — gold Argento Homes lettering extracted from original, transparent.
- `Argento_Homes_Primary_Transparent.png` — combined leaf + gold wordmark, transparent.
- `Argento_QA_cream.png` and `Argento_QA_teal.png` — diagnostic previews only, **not logo assets**.
- `Argento_Homes_Original_Source.png` — unmodified original reference for fidelity comparison.

## Usage and limitations
- Use the primary transparent PNG on a sufficiently dark or contrasting field. Gold lettering is low-contrast on cream/beige; do not change its colors silently.
- This kit preserves raster source pixels and has an approximated, anti-aliased transparency mask. It is NOT a mathematically exact editable vector master or a confirmed commercial typeface.
- Inspect leaf tips, small branches, and text strokes at 100% before final approval. Some dark-source matte contamination may remain at edges.
- Do not treat the preview background as part of the logo.
- No production publishing or changes to brand-level canonical files are authorized by this kit.
