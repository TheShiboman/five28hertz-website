# Argento Homes transparent identity — v2 founder review candidate

Status: **PENDING FOUNDER APPROVAL / NOT CANONICAL.**
Source: the actual Argento Homes Logo.png (500×500); original gold wordmark extracted edges rejected.
Leaf: exact previously accepted transparent leaf crop (243×340), unchanged pixel source and color palette, positioned at x=127, y=60 of original 500px coordinate system.
Lettering: newly typeset **Cormorant Garamond Regular**; closest visual test against original using four candidates, **NOT confirmed as historical font**.
Geometry: original leaf-to-text vertical position preserved at approximate 21px visible gap (leaf ink to new ink), original letter bounding width matched to 300px, centered x=100.
Gold: new clean raster antialiasing with warm metallic gradient sampled as visual interpretation: #FFE5B1 > #F1CF95 > #DEAD6C > #B17C46, not a measured metallic reproduction.
Artifacts: high-resolution transparent PNG 2000×2000; 500px transparent PNG; crisp transparent wordmark; leaf; original; source-vs-rebuild comparison; dark and cream previews.
The warm-cream preview intentionally exhibits lower wordmark contrast. Dark preview is only diagnostic, not logo background.
The wordmark is rendered at 4× source resolution, **not an editable vector font master**.
Do not update the website panel, canon, or production without founder visual approval.
